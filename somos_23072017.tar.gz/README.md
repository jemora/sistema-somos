# Somos
Sistema de Registro y Seguimiento Somos Venezuela Amazonas

### Desarrollado por Jaime E. Mora