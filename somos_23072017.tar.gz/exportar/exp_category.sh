#!/bin/sh
php exp_category.php > ../export/category.csv