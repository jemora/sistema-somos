#!/bin/sh
php exp_ticket.php > ../export/ticket.csv