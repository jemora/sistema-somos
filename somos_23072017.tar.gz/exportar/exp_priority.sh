#!/bin/sh
php exp_priority.php > ../export/priority.csv