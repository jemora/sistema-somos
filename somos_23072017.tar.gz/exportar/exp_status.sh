#!/bin/sh
php exp_status.php > ../export/status.csv