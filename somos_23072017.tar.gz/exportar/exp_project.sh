#!/bin/sh
php exp_project.php > ../export/project.csv