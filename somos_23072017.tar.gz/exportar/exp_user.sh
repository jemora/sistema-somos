#!/bin/sh
php exp_user.php > /var/www/html/somos/export/user.csv