#!/bin/sh
php exp_kind.php > ../export/kind.csv